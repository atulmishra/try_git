package com.citi.otc.dashboard.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.citi.otc.dashboard.domain.Answers;
import com.citi.otc.dashboard.domain.QuestionToAnswers;
import com.citi.otc.dashboard.domain.Questions;

public interface QuestionToAnswersRepository extends JpaRepository<QuestionToAnswers, Integer> {

	List<QuestionToAnswers> findByQuestion(Questions question);
}
