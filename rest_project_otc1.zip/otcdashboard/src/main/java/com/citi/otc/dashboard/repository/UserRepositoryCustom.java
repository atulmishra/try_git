package com.citi.otc.dashboard.repository;


public interface UserRepositoryCustom  {

	void increaseCurrentCredit(float val);
}
