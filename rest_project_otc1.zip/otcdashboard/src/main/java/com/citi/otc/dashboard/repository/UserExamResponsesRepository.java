package com.citi.otc.dashboard.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.citi.otc.dashboard.domain.UserExamResponses;

public interface UserExamResponsesRepository extends JpaRepository<UserExamResponses,Integer>,UserExamResponsesRepositoryCustom{

}
