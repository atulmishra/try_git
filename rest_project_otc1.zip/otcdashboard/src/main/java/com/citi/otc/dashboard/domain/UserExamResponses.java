package com.citi.otc.dashboard.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
@Entity
public class UserExamResponses {
	
	@Id
	@SequenceGenerator(name = "UserExamResponses_Sequence", sequenceName = "USEREXAMRESPONSES_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "UserExamResponses_Sequence")
	@Column(name = "id", nullable = false)
	private long id;

	
	@Column
	private String response;

	@ManyToOne(optional = false)
	@JoinColumn(name = "exam_id", unique=false)
	private TestExam exam;
	
	@ManyToOne(optional = false)
	@JoinColumn(name = "username", unique=false)
	private Users user;
	
	@OneToOne(optional = false)
	@JoinColumn(name = "quest_id")
	private Questions question;
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}


	public TestExam getExam() {
		return exam;
	}

	public void setExam(TestExam exam) {
		this.exam = exam;
	}

	public Questions getQuestion() {
		return question;
	}

	public void setQuestion(Questions question) {
		this.question = question;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public Users getUser() {
		return user;
	}

	public void setUser(Users user) {
		this.user = user;
	}
	
}
