package com.citi.otc.dashboard.repository;

public interface UserExamResponsesRepositoryCustom {
	public void reduceInventory(int qty);

}
