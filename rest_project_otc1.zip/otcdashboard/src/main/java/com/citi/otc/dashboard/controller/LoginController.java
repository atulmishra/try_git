package com.citi.otc.dashboard.controller;

import java.util.List;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.citi.otc.dashboard.domain.Users;
import com.citi.otc.dashboard.services.UserService;

/**
 * Sample controller for going to the home page with a message
 */
@Controller
public class LoginController {

	private static final Logger logger = LoggerFactory
			.getLogger(LoginController.class);


	@Autowired
	UserService userService;

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public @ResponseBody Users login(@RequestParam("username") String username,
			@RequestParam("password") String password) {
		logger.debug("Received request to login username  : " + username
				+ " and password" + password);
		return (userService.login(username, password));
	}

}
