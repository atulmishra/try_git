package com.citi.otc.dashboard.services;

import java.util.List;

import com.citi.otc.dashboard.domain.Answers;
import com.citi.otc.dashboard.domain.TestExam;
import com.citi.otc.dashboard.domain.UserExam;
import com.citi.otc.dashboard.view.ExamView;
import com.citi.otc.dashboard.view.UserExamView;
import com.citi.otc.dashboard.view.UserResponseView;

public interface ExamService {
	public UserExam submitResult(UserExamView results)  ;
	public boolean submitResponses(List<UserResponseView> response)  ;
	public TestExam getExamDetails(int examCode);
	public List<Answers> getAnswersListFromQuestion(int questId);
	ExamView getExamDescription(int examCode);
	ExamView getFullExamDetails(int examCode);
	public boolean isTimeUp(int examId);


}
