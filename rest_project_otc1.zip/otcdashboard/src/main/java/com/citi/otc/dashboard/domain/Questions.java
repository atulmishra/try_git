package com.citi.otc.dashboard.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
public class Questions implements Serializable{

	@Id
	@SequenceGenerator(name = "QuesId_Sequence", sequenceName = "QUESTIONS_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "QuesId_Sequence")
	@Column(name = "quest_id", nullable = false)
	private int questId;

	@Column
	private String title;

	@Column
	private String description;

	@Column
	private boolean isMultipleAnswer;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "exam_id", nullable = false)
	@JsonBackReference
	private TestExam exam;

	public int getQuestId() {
		return questId;
	}

	public void setQuestId(int questId) {
		this.questId = questId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isMultipleAnswer() {
		return isMultipleAnswer;
	}

	public void setMultipleAnswer(boolean isMultipleAnswer) {
		this.isMultipleAnswer = isMultipleAnswer;
	}

	
	public TestExam getExam() {
		return exam;
	}

	public void setExam(TestExam exam) {
		this.exam = exam;
	}
	public Questions() {
		super();
	}

	public Questions(int questId) {
		super();
		this.questId = questId;
	}

}
