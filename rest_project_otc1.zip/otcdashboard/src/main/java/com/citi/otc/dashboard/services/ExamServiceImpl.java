package com.citi.otc.dashboard.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.citi.otc.dashboard.domain.Answers;
import com.citi.otc.dashboard.domain.QuestionToAnswers;
import com.citi.otc.dashboard.domain.Questions;
import com.citi.otc.dashboard.domain.TestExam;
import com.citi.otc.dashboard.domain.UserExam;
import com.citi.otc.dashboard.domain.UserExamResponses;
import com.citi.otc.dashboard.domain.Users;
import com.citi.otc.dashboard.repository.QuestionToAnswersRepository;
import com.citi.otc.dashboard.repository.TestExamRepository;
import com.citi.otc.dashboard.repository.UserExamRepository;
import com.citi.otc.dashboard.repository.UserExamResponsesRepository;
import com.citi.otc.dashboard.view.ExamView;
import com.citi.otc.dashboard.view.QuestionsView;
import com.citi.otc.dashboard.view.UserExamView;
import com.citi.otc.dashboard.view.UserResponseView;

@Service
@Scope("prototype")
public class ExamServiceImpl implements ExamService {

	@Resource
	UserExamRepository userExamRepository;

	@Override
	@Transactional
	public UserExam submitResult(UserExamView results) {
		UserExam u=new UserExam();
		TestExam t= new TestExam();
		Users user =new Users();
		user.setUsername(results.getUsername());
		t.setExamId(results.getExamId());
		u.setExam(t);
		u.setUser(user);
		u.setMarks(results.getMarks());
		return userExamRepository.save(u);

	}

	@Resource
	UserExamResponsesRepository userExamResponsesRepository;

	@Override
	@Transactional
	public boolean submitResponses(List<UserResponseView> responses) {
		boolean flag = true;
		for (UserResponseView response : responses) {
			UserExamResponses a = new UserExamResponses();
			TestExam t = new TestExam();
			t.setExamId(response.getExamId());
			Questions q = new Questions();
			q.setQuestId(response.getQuestId());
			Users u = new Users();
			u.setUsername(response.getUserName());
			a.setExam(t);
			a.setQuestion(q);
			a.setResponse(response.getUserResponse());
			a.setUser(u);
			a=userExamResponsesRepository.save(a);
			if(a==null) flag=false;
		}
		return flag;
	}

	@Resource
	TestExamRepository testExamrepository;
	@Resource
	QuestionToAnswersRepository questToAnsrepository;

	@Override
	@Transactional
	public TestExam getExamDetails(int examCode) {

		TestExam obj = testExamrepository.findOne(examCode);
		return obj;
	}

	@Override
	@Transactional
	public ExamView getExamDescription(int examCode) {

		TestExam obj = testExamrepository.findOne(examCode);
		ExamView examView = new ExamView(obj.getExamId(), obj.getName(), obj.getDescription(), obj.getExamDuration());
		// setAnswersInQuestions(obj);
		return examView;
	}

	@Override
	@Transactional
	public ExamView getFullExamDetails(int examCode) {

		TestExam obj = testExamrepository.findOne(examCode);
		ExamView examView = new ExamView(obj.getExamId(), obj.getName(), obj.getDescription(), obj.getExamDuration());

		List<QuestionsView> questions = new ArrayList<>();

		List<Questions> questList = obj.getQuestions();
		for (int i = 0; i < questList.size(); i++) {
			Questions q = questList.get(i);
			List<Answers> ansList = getAnswersListFromQuestion(q.getQuestId());
			QuestionsView qv = new QuestionsView(q, ansList);
			questions.add(qv);
		}
		examView.setQuestions(questions);
		
		startTime= new Date();
		duration= obj.getExamDuration();
		// setAnswersInQuestions(obj);
		return examView;
	}

	@Override
	public List<Answers> getAnswersListFromQuestion(int questId) {
		Questions q = new Questions();
		q.setQuestId(questId);
		List<Answers> ansList = new ArrayList<>();

		List<QuestionToAnswers> questToAnsList = questToAnsrepository.findByQuestion(q);
		for (int j = 0; j < questToAnsList.size(); j++) {
			QuestionToAnswers a = questToAnsList.get(j);

			ansList.add(a.getAnswer());
		}
		return ansList;
	}
	 private volatile Date startTime;
	int duration;

	@Override
	public boolean isTimeUp(int examId) {
		
		//TestExam t =getExamDetails(examId);
		
		//ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor();
		
		TimeLeft tl = new TimeLeft(startTime, duration,1);
		
		
		if(tl.getDifference()>tl.getDuration()) return false;
		else return true;
		//Timer t = new Timer(tl);
		
		// then, when you want to schedule a task
		//Runnable task = ....    
		//executor.schedule(task, 5, TimeUnit.SECONDS);

		// and finally, when your program wants to exit
		//executor.shutdown();
	//	return false;
	}

}
