package com.citi.otc.dashboard.services;

import java.util.Date;

public class TimeLeft {
	private Date startTime;
	private long duration;
	private int difference;
	
	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public long getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public long getDifference() {
		return (new Date().getTime()-startTime.getTime())/1000;
	}
	public void setDifference(int difference) {
		this.difference = difference;
	}
	public TimeLeft(Date startTime, long duration, int difference) {
		super();
		this.startTime = startTime;
		this.duration = duration;
		this.difference = difference;
	}
	

}
