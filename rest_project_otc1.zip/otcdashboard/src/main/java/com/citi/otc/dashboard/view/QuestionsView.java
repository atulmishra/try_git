package com.citi.otc.dashboard.view;

import java.util.List;

import com.citi.otc.dashboard.domain.Answers;
import com.citi.otc.dashboard.domain.Questions;

public class QuestionsView {
	
	Questions question;
	List<Answers> answers;
	public Questions getQuestion() {
		return question;
	}
	public void setQuestion(Questions question) {
		this.question = question;
	}
	public List<Answers> getAnswers() {
		return answers;
	}
	public void setAnswers(List<Answers> answers) {
		this.answers = answers;
	}
	public QuestionsView() {
		super();
		// TODO Auto-generated constructor stub
	}
	public QuestionsView(Questions question, List<Answers> answers) {
		super();
		this.question = question;
		this.answers = answers;
	}
	

}
