package com.citi.otc.dashboard.services;

import java.util.List;

import com.citi.otc.dashboard.domain.Answers;
import com.citi.otc.dashboard.domain.JobsDescription;
import com.citi.otc.dashboard.domain.TestExam;
import com.citi.otc.dashboard.domain.UserExam;
import com.citi.otc.dashboard.view.ExamView;
import com.citi.otc.dashboard.view.JobView;
import com.citi.otc.dashboard.view.UserExamView;
import com.citi.otc.dashboard.view.UserResponseView;

public interface JobService {
	public JobsDescription getJobDetails(Long jobId);
	
	
}
