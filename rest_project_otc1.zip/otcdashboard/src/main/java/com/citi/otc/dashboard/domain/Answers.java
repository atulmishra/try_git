package com.citi.otc.dashboard.domain;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonBackReference;
@Entity
public class Answers {

	
	@Id
	@SequenceGenerator(name = "AnsId_Sequence", sequenceName = "ANSWERS_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "AnsId_Sequence")
	@Column(name = "ans_id", nullable = false, updatable=false,insertable=false)
	private int ansId;
	
	@Column
	private String answerChoiceText;
	
	@Column
	private int displayOrder;
	
	@Column
	private boolean isCorrectChoice;
	
	
	
	public int getAnsId() {
		return ansId;
	}

	public void setAnsId(int ansId) {
		this.ansId = ansId;
	}

	public String getAnswerChoiceText() {
		return answerChoiceText;
	}

	public void setAnswerChoiceText(String answerChoiceText) {
		this.answerChoiceText = answerChoiceText;
	}

	public int getDisplayOrder() {
		return displayOrder;
	}

	public void setDisplayOrder(int displayOrder) {
		this.displayOrder = displayOrder;
	}

	public boolean isCorrectChoice() {
		return isCorrectChoice;
	}

	public void setCorrectChoice(boolean isCorrectChoice) {
		this.isCorrectChoice = isCorrectChoice;
	}


}
