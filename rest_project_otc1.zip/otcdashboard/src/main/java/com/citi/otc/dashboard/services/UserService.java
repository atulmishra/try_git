package com.citi.otc.dashboard.services;

import com.citi.otc.dashboard.domain.Users;


public interface UserService {
	public Users login(String user,String password);

}
