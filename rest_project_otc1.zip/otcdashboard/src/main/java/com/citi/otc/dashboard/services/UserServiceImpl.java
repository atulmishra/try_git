package com.citi.otc.dashboard.services;

import java.util.UUID;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.citi.otc.dashboard.domain.Users;
import com.citi.otc.dashboard.repository.UserRepository;
@Service
@Scope("prototype")
public class UserServiceImpl implements UserService {
	@Resource
	UserRepository userRepository;

	@Override
	public Users login(String username,String password) {
		Users userFound = userRepository.findOne(username);
		
		if (userFound!=null&&userFound.getPassword().equals(password))
		{
		    String session = UUID.randomUUID().toString().replace("-", "");
			userFound.setSessionId(session);
			//userRepository.save(userFound);
			return userFound;
		}
		else{
			Users arbit = new Users();
			arbit.setSessionId(null);
			arbit.setUsername(username);
			arbit.setPassword(password);
			return arbit;
			
		}
	}

}
