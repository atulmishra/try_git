package com.citi.otc.dashboard.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.citi.otc.dashboard.domain.TestExam;

public interface TestExamRepository extends JpaRepository<TestExam, Integer> {

}
