package com.citi.otc.dashboard.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.citi.otc.dashboard.domain.JobsDescription;

public interface JobsDescriptionRepository extends JpaRepository<JobsDescription, Long> {

}
