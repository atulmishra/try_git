package com.citi.otc.dashboard.view;

import java.util.List;

import org.springframework.stereotype.Component;

public class ExamView {

	private int examId;

	private String name;
	private String description;
	private int examDuration;

	public ExamView() {
		super();
		// TODO Auto-generated constructor stub
	}



	public ExamView(int examId, String name, String description,
			int examDuration) {
		super();
		this.examId = examId;
		this.name = name;
		this.description = description;
		this.examDuration = examDuration;
	}



	public int getExamId() {
		return examId;
	}

	public void setExamId(int examId) {
		this.examId = examId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getExamDuration() {
		return examDuration;
	}

	public void setExamDuration(int examDuration) {
		this.examDuration = examDuration;
	}


	List<QuestionsView> questions;

	public List<QuestionsView> getQuestions() {
		return questions;
	}

	public void setQuestions(List<QuestionsView> questions) {
		this.questions = questions;
	}

}
