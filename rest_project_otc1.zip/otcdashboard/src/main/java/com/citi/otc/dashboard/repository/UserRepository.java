package com.citi.otc.dashboard.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.citi.otc.dashboard.domain.Users;

public interface UserRepository extends JpaRepository<Users, String>,UserRepositoryCustom {

}
