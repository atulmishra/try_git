package com.jobss.controller;

public interface Arjun {

}
