package com.crossover.trial.weather.domain.gis;

public interface Point {
    double latitude();

    double longitude();
}
