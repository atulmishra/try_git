package com.gteam.saleorders.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.gteam.saleorders.exceptions.EntityNotFound;
import com.gteam.saleorders.model.Product;

public interface ProductService {
	public Product create(Product product);
	public boolean delete(int prodCode) throws EntityNotFound;
	public List<Product> findAll();
	public Product update(Product product) throws EntityNotFound;
	public Product findById(int prodCode);


}
