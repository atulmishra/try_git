package com.gteam.saleorders.model;

import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Customer {
	@Id
	@Column(name = "CUST_CODE", nullable = false)
    
	private int custCode;
	
	@Column
	private String name;
	@Column
	private String address;
	@Column
	private String phone1;
	@Column
	private String phone2;
	@Column(name="credit_limit")
	private float creditLimit;
	@Column(name="current_credit")
	private float currentCredit;
	
	/*@OneToMany(mappedBy="customer",targetEntity=Order.class,
		       fetch=FetchType.EAGER)
		       private Collection orders;
	*/
	//getters and setters
	
	public int getCustCode() {
		return custCode;
	}
	public void setCustCode(int custCode) {
		this.custCode = custCode;
	}
	/*public Collection getOrders() {
		return orders;
	}
	public void setOrders(Collection orders) {
		this.orders = orders;
	}*/
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone1() {
		return phone1;
	}
	public void setPhone1(String phone1) {
		this.phone1 = phone1;
	}
	public String getPhone2() {
		return phone2;
	}
	public void setPhone2(String phone2) {
		this.phone2 = phone2;
	}
	public float getCreditLimit() {
		return creditLimit;
	}
	public void setCreditLimit(float creditLimit) {
		this.creditLimit = creditLimit;
	}
	public float getCurrentCredit() {
		return currentCredit;
	}
	public void setCurrentCredit(float currentCredit) {
		this.currentCredit = currentCredit;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Customer [custCode=" + custCode + ", name=" + name
				+ ", address=" + address + ", phone1=" + phone1 + ", phone2="
				+ phone2 + ", creditLimit=" + creditLimit + ", currentCredit="
				+ currentCredit + "]";
	}
	
	
	

}
