package com.gteam.saleorders.repository;


public interface CustomerRepositoryCustom  {

	void increaseCurrentCredit(float val);
}
