package com.gteam.saleorders.services;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gteam.saleorders.exceptions.EntityNotFound;
import com.gteam.saleorders.exceptions.EntityNotValid;
import com.gteam.saleorders.model.Order;
import com.gteam.saleorders.model.OrderLines;
import com.gteam.saleorders.model.Product;
import com.gteam.saleorders.repository.CustomerRepository;
import com.gteam.saleorders.repository.OrderRepository;
import com.gteam.saleorders.repository.ProductRepository;
@Service
public class OrderServiceImpl implements OrderService {
	
	@Resource
	OrderRepository orderRepository;
	
	@Resource
	ProductRepository productRepository;
	
	@Resource
	CustomerRepository customerRepository;
	
	

	@Transactional(rollbackFor=EntityNotValid.class)
	public Order create(Order order) throws  EntityNotValid {
		Order createdOrder=order;
		if(!validate(order)){
			throw new EntityNotValid("Order is not Valid");
		}
		
		Product p=null;
		
		//reduce inventory
		for(OrderLines l:order.getOrderLines()){
			 p=l.getProduct();
			 productRepository.reduceInventory(l.getProduct().getQuantity()-l.getQuantity());
			
		}
		
		//increase credit
		customerRepository.increaseCurrentCredit(order.getCustomer().getCurrentCredit()+order.getTotalPrice());
		
		return orderRepository.save(createdOrder);
	}

	@Transactional(rollbackFor=EntityNotFound.class)
	public boolean delete(int orderNumber) throws EntityNotFound {
		Order deletedOrder=orderRepository.findOne(orderNumber);
		if(deletedOrder==null){
			throw new EntityNotFound();
		}
		orderRepository.delete(deletedOrder);
		return !(deletedOrder==null);
	}

	@Transactional
	public List<Order> findAll() {
		return orderRepository.findAll();
	}

	@Transactional(rollbackFor=EntityNotValid.class)
	public Order update(Order order) throws  EntityNotValid, EntityNotFound {
		Order updatedOrder = orderRepository.findOne(order.getOrderNumber());
		if(!validate(order)){
			throw new EntityNotValid("Order is not Valid");
		}
		if (updatedOrder == null)
			throw new EntityNotFound();

		updatedOrder.setCustomer(order.getCustomer());
		updatedOrder.setTotalPrice(order.getTotalPrice());
		updatedOrder.setOrderLines(order.getOrderLines());
		
		return orderRepository.save(updatedOrder);
	
	}
	
	@Transactional
	public Order findById(int orderNumber) {
		return orderRepository.findOne(orderNumber);
	}
	
	public boolean validate(Order order) {
		boolean flag = false;
		Product p =null;
		if ((order.getTotalPrice() < (order.getCustomer().getCreditLimit() - order
				.getCustomer().getCurrentCredit()))) {
			flag = true;
			for(OrderLines l:order.getOrderLines()){
				 p=l.getProduct();
				 if(p.getQuantity()<l.getQuantity()){
					 flag=false;
				 }
			}

			
		}
		
		return flag;
		
	}

}
