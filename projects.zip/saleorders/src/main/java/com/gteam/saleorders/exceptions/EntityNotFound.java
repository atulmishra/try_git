package com.gteam.saleorders.exceptions;

public class EntityNotFound extends Exception {
	
	 private String message = null;
	 
	    public EntityNotFound() {
	        super();
	    }
	 
	    public EntityNotFound(String message) {
	        super(message);
	        this.message = message;
	    }
	 
	    public EntityNotFound(Throwable cause) {
	        super(cause);
	    }
	 
	    @Override
	    public String toString() {
	        return message;
	    }
	 
	    @Override
	    public String getMessage() {
	        return message;
	    }

}
