package com.gteam.saleorders.controller;

import java.util.List;

import com.gteam.saleorders.exceptions.EntityNotFound;
import com.gteam.saleorders.model.Customer;
import com.gteam.saleorders.model.Product;
import com.gteam.saleorders.services.ProductService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/product/")
public class ProductController {
	
	private static final Logger logger = LoggerFactory.getLogger(ProductController.class);

	@Autowired
	private ProductService productService;
	
	
	@RequestMapping(value="create",method = RequestMethod.POST,
            headers = {"Content-type=application/json"})
	public @ResponseBody Product createProduct(@RequestBody Product product) {
		logger.debug("Received request to create product  : "+product);				

		return productService.create(product);
	}

	@RequestMapping(value="edit",method = RequestMethod.PUT,
            headers = {"Content-type=application/json"})
	public @ResponseBody Product updateProduct(@RequestBody Product product) throws EntityNotFound{
		return productService.update(product);
	}
	
	@RequestMapping(value="delete/{code}",method = RequestMethod.GET)
	public @ResponseBody boolean deleteProduct(@PathVariable("code") int prodCode) throws EntityNotFound{
		return productService.delete(prodCode);
	}
	
	@RequestMapping(value="list",method = RequestMethod.GET)
	public @ResponseBody List<Product> listProduct(){
		return productService.findAll();
	}
	@RequestMapping(value="find/{code}",method = RequestMethod.GET)
	public @ResponseBody Product findProduct(@PathVariable("code") int prodCode) throws EntityNotFound{
		logger.debug("Received request to get customer by id  : "+prodCode);				

		return productService.findById(prodCode);
	}
	
	

}
