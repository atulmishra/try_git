package com.gteam.saleorders.services;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gteam.saleorders.exceptions.EntityNotFound;
import com.gteam.saleorders.model.Customer;
import com.gteam.saleorders.repository.CustomerRepository;
@Service
public class CustomerServiceImpl implements CustomerService {
	
	@Resource
	CustomerRepository customerRepository;

	@Transactional
	public Customer create(Customer customer) {
		Customer createdCustomer=customer;
		return customerRepository.save(createdCustomer);
	}

	@Transactional(rollbackFor=EntityNotFound.class)
	public boolean delete(int custCode) throws EntityNotFound {
		Customer deletedCustomer=customerRepository.findOne(custCode);
		if(deletedCustomer==null){
			throw new EntityNotFound();
		}
		customerRepository.delete(deletedCustomer);
		return !(deletedCustomer==null);
	}

	@Transactional
	public List<Customer> findAll() {
		return customerRepository.findAll();
	}

	@Transactional(rollbackFor=EntityNotFound.class)
	public Customer update(Customer customer) throws EntityNotFound {
		Customer updatedCustomer = customerRepository.findOne(customer.getCustCode());

		if (updatedCustomer == null)
			throw new EntityNotFound();

		updatedCustomer.setName(customer.getName());
		updatedCustomer.setAddress(customer.getAddress());
		updatedCustomer.setPhone1(customer.getPhone1());
		updatedCustomer.setPhone2(customer.getPhone2());
		updatedCustomer.setCreditLimit(customer.getCreditLimit());
		updatedCustomer.setCurrentCredit(customer.getCurrentCredit());
		return customerRepository.save(updatedCustomer);
	
	}
	
	@Transactional
	public Customer findById(int custCode) {
		return customerRepository.findOne(custCode);
	}

}
