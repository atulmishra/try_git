package com.gteam.saleorders.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.JpaRepositoryConfigExtension;

import com.gteam.saleorders.model.Product;

public interface ProductRepository extends JpaRepository<Product,Integer>,ProductRepositoryCustom{

}
