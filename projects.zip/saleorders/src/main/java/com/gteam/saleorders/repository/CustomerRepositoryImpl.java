package com.gteam.saleorders.repository;

import org.springframework.data.jpa.repository.Query;


public class CustomerRepositoryImpl implements CustomerRepositoryCustom{

	@Query(value="update #{#entityName} SET current_credit = ?1",nativeQuery=true)
	public void increaseCurrentCredit( float val) {
		 
	}
}
