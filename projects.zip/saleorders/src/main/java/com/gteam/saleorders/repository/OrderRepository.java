package com.gteam.saleorders.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gteam.saleorders.model.Order;

public interface OrderRepository extends JpaRepository<Order, Integer> {

}
