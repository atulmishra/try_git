package com.gteam.saleorders.repository;

public interface ProductRepositoryCustom {
	public void reduceInventory(int qty);

}
