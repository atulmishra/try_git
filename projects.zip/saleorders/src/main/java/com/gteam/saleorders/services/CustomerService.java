package com.gteam.saleorders.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.gteam.saleorders.exceptions.EntityNotFound;
import com.gteam.saleorders.model.Customer;

public interface CustomerService {
	public Customer create(Customer customer);
	public boolean delete(int custCode) throws EntityNotFound;
	public List<Customer> findAll();
	public Customer update(Customer customer) throws EntityNotFound;
	public Customer findById(int custCode);


}
