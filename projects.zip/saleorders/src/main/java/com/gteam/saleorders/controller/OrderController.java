package com.gteam.saleorders.controller;

import java.util.List;

import com.gteam.saleorders.exceptions.EntityNotFound;
import com.gteam.saleorders.exceptions.EntityNotValid;
import com.gteam.saleorders.model.Order;
import com.gteam.saleorders.services.OrderService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/order/")
public class OrderController {
	
	private static final Logger logger = LoggerFactory.getLogger(OrderController.class);

	@Autowired
	private OrderService orderService;
	
	
	@RequestMapping(value="create",method = RequestMethod.POST,
            headers = {"Content-type=application/json"})
	public @ResponseBody Order createOrder(@RequestBody Order order) throws EntityNotValid {
		logger.debug("Received request to create order  : "+order);				

		return orderService.create(order);
	}

	@RequestMapping(value="edit",method = RequestMethod.PUT,
            headers = {"Content-type=application/json"})
	public @ResponseBody Order updateOrder(@RequestBody Order order) throws EntityNotFound, EntityNotValid{
		logger.debug("Received request to edit order  : "+order);				

		return orderService.update(order);
	}
	
	
	
	@RequestMapping(value="list",method = RequestMethod.GET)
	public @ResponseBody List<Order> listOrder(){
		logger.debug("Received request to get all orders   ");				

		return orderService.findAll();
	}
	
	@RequestMapping(value="delete/{code}",method = RequestMethod.GET)
	public @ResponseBody boolean deleteOrder(@PathVariable("code") int orderNumber) throws EntityNotFound{
		logger.debug("Received request to delete order by id  : "+orderNumber);				

		return orderService.delete(orderNumber);
	}
	
	@RequestMapping(value="find/{code}",method = RequestMethod.GET)
	public @ResponseBody Order findOrder(@PathVariable("code") int orderNumber) throws EntityNotFound{
		logger.debug("Received request to get order by id  : "+orderNumber);				

		return orderService.findById(orderNumber);
	}
	
	
	

}
