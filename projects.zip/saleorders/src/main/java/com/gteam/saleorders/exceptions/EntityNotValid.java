package com.gteam.saleorders.exceptions;

public class EntityNotValid extends Exception {
	
	 private String message = null;
	 
	    public EntityNotValid() {
	        super();
	    }
	 
	    public EntityNotValid(String message) {
	        super(message);
	        this.message = message;
	    }
	 
	    public EntityNotValid(Throwable cause) {
	        super(cause);
	    }
	 
	    @Override
	    public String toString() {
	        return message;
	    }
	 
	    @Override
	    public String getMessage() {
	        return message;
	    }

}
