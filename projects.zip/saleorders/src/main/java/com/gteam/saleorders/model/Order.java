package com.gteam.saleorders.model;

import java.util.Collection;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity(name = "orders")
public class Order {

	@Id
	@Column(name="order_number")
	private int orderNumber;
	
	/*@Column(name="customer_code" ,insertable = false, updatable = false)
	private int customerCode;*/
	
	@Column(name="total_price")
	private float totalPrice;

	@ManyToOne(optional=false)
    @JoinColumn(name="customer_code",referencedColumnName="cust_code")
    private Customer customer;
	
	
	@OneToMany(mappedBy="order",targetEntity=OrderLines.class,
		       fetch=FetchType.EAGER)
	@JsonManagedReference
		       private List<OrderLines> orderLines;
	
	/*@LazyCollection(LazyCollectionOption.FALSE)
	@ManyToMany
    @JoinTable(name="order_detail",
            joinColumns=
            @JoinColumn(name="order_number", referencedColumnName="order_number"),
      inverseJoinColumns=
            @JoinColumn(name="prod_code", referencedColumnName="prod_code")
    )
    private List<Product> productList; 
	*/

	

	/*public List<Product> getProductList() {
		return productList;
	}

	public void setProductList(List<Product> productList) {
		this.productList = productList;
	}*/

	public int getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(int orderNumber) {
		this.orderNumber = orderNumber;
	}

	/*public int getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(int customerCode) {
		this.customerCode = customerCode;
	}*/

	public float getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(float totalPrice) {
		this.totalPrice = totalPrice;
	}

	@Override
	public String toString() {
		return "Order [orderNumber=" + orderNumber + ", customerCode="
				+ customer.getCustCode() + ", totalPrice=" + totalPrice + ", customer="
				+ customer + "]";
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public List<OrderLines> getOrderLines() {
		return orderLines;
	}

	public void setOrderLines(List<OrderLines> ordersLines) {
		this.orderLines = ordersLines;
	}
	
	
}
