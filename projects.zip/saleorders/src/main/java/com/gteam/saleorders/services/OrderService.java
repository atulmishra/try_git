package com.gteam.saleorders.services;

import java.util.List;


import com.gteam.saleorders.exceptions.EntityNotFound;
import com.gteam.saleorders.exceptions.EntityNotValid;
import com.gteam.saleorders.model.Order;

public interface OrderService {
	public Order create(Order order) throws  EntityNotValid;
	public boolean delete(int orderNumber) throws EntityNotFound;
	public List<Order> findAll();
	public Order update(Order order) throws  EntityNotValid, EntityNotFound;
	public Order findById(int orderNumber);


}
