package com.gteam.saleorders.controller;

import java.util.List;

import com.gteam.saleorders.exceptions.EntityNotFound;
import com.gteam.saleorders.model.Customer;
import com.gteam.saleorders.services.CustomerService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/customer/")
public class CustomerController {
	
	private static final Logger logger = LoggerFactory.getLogger(CustomerController.class);

	@Autowired
	private CustomerService customerService;
	
	
	@RequestMapping(value="create",method = RequestMethod.POST,
            headers = {"Content-type=application/json"})
	public @ResponseBody Customer createCustomer(@RequestBody Customer customer) {
		logger.debug("Received request to create customer  : "+customer);				

		return customerService.create(customer);
	}

	@RequestMapping(value="edit",method = RequestMethod.PUT,
            headers = {"Content-type=application/json"})
	public @ResponseBody Customer updateCustomer(@RequestBody Customer customer) throws EntityNotFound{
		logger.debug("Received request to edit customer  : "+customer);				

		return customerService.update(customer);
	}
	
	@RequestMapping(value="delete/{code}",method = RequestMethod.GET)
	public @ResponseBody boolean deleteCustomer(@PathVariable("code") int custCode) throws EntityNotFound{
		logger.debug("Received request to delete customer  : "+custCode);				

		return customerService.delete(custCode);
	}
	
	@RequestMapping(value="list",method = RequestMethod.GET)
	public @ResponseBody List<Customer> listCustomer(){
		logger.debug("Received request to get all customers   ");				

		return customerService.findAll();
	}
	
	@RequestMapping(value="find/{code}",method = RequestMethod.GET)
	public @ResponseBody Customer findCustomer(@PathVariable("code") int custCode) throws EntityNotFound{
		logger.debug("Received request to get customer by id  : "+custCode);				

		return customerService.findById(custCode);
	}
	
	
	

}
