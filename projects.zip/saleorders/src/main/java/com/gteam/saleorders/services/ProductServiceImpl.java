package com.gteam.saleorders.services;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gteam.saleorders.exceptions.EntityNotFound;
import com.gteam.saleorders.model.Product;
import com.gteam.saleorders.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService{

	@Resource
	private ProductRepository productRepository;
	
	@Transactional
	public Product create(Product product) {
		Product createdProduct= product;
		return productRepository.save(createdProduct);
	}
	
	
	@Transactional(rollbackFor=EntityNotFound.class)
	public boolean delete(int prodCode) throws EntityNotFound {
			Product deletedProduct=productRepository.findOne(prodCode);
			if(deletedProduct==null){
				throw new EntityNotFound();
			}
			productRepository.delete(deletedProduct);
			return !(deletedProduct==null);
	}

	@Transactional
	public List<Product> findAll() {
		 return productRepository.findAll();
	}
	
	@Transactional(rollbackFor=EntityNotFound.class)
	public Product update(Product product) throws EntityNotFound {
		Product updatedProduct = productRepository.findOne(product.getProdCode());

		if (updatedProduct == null)
			throw new EntityNotFound();

		updatedProduct.setDescription(product.getDescription());
		updatedProduct.setPrice(product.getPrice());
		updatedProduct.setQuantity(product.getQuantity());
		updatedProduct.setProdCode(product.getProdCode());
		return productRepository.save(updatedProduct);
	}
	@Transactional
	public Product findById(int prod_code) {
		 return productRepository.findOne(prod_code);
	}
	
	
	
	

}
