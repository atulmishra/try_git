
public class WaterStored {
		 
	       public static void main ( String[] args){
	             
	    	   WaterStored content = new WaterStored();
	             
	              int startIndex = -1;
	              int endIndex = -1;
	              int total = 0;
	              int wall[]={5,3,7,2,6,4,5,9,1,2};
	              int wall2[] = new int[wall.length];
	             
	              for(int i=0;i<wall.length-1;i++){
	                    
	                     if(wall[i]>wall[i+1]){
	                           startIndex = i;
	                          
	                           for(int j=i+1;j<wall.length;j++){
	                                  if(wall[j] > wall[startIndex]) {
	                                         endIndex = j;
	                                         total += content.calculateWater(startIndex , endIndex, wall);
	                                         startIndex = endIndex;
	                                  }
	                           }
	                           i=wall.length-1;
	                          
	                     }
	              }
	             
	              for(int i=0;i<wall.length-1;i++){
	                     wall2[i]=wall[wall.length-1-i];
	              }
	             
	              for(int i=0;i<wall2.length-1;i++){
	                                 
	                                  if(wall2[i]>wall2[i+1]){
	                                         startIndex = i;
	                                        
	                                         for(int j=i+1;j<wall2.length;j++){
	       	                                  if(wall2[j] >=wall2[startIndex]) {
	       	                                         endIndex = j;
	       	                                         total += content.calculateWater(startIndex , endIndex, wall2);
	       	                                         startIndex = endIndex;
	       	                                  }
	       	                           }
	       	           
	       	                          i=wall2.length-1; 
	                                  }
	                           }
	             
	              System.out.print(total);
	             
	       }
	      
	       private int calculateWater(int startIndex , int endIndex, int[] arr){
	             
	             
	              int length = endIndex-startIndex+1;
	              int longWall = Math.max(arr[startIndex], arr[endIndex]);
	              int smallWall = Math.min(arr[startIndex], arr[endIndex]);
	             
	              int amount = (smallWall * length) - smallWall + longWall;
	             
	              for(int i= startIndex; i<=endIndex; i++){
	                          
	                     amount = amount-arr[i];                        
	              }
	              return amount;
	       }
	      
	      
	}

