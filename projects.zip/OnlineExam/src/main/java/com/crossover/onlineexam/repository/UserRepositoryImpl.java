package com.crossover.onlineexam.repository;

import org.springframework.data.jpa.repository.Query;


public class UserRepositoryImpl implements UserRepositoryCustom{

	@Query(value="update #{#entityName} SET current_credit = ?1",nativeQuery=true)
	public void increaseCurrentCredit( float val) {
		 
	}
}
