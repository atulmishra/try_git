package com.crossover.onlineexam.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.crossover.onlineexam.domain.User;

public interface UserRepository extends JpaRepository<User, String>,UserRepositoryCustom {

}
