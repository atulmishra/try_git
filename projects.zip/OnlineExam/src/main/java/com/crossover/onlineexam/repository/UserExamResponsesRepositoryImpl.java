package com.crossover.onlineexam.repository;

import org.springframework.data.jpa.repository.Query;

public class UserExamResponsesRepositoryImpl implements UserExamResponsesRepositoryCustom{

	@Query(value="update #{#entityName} SET quantity = ?1",nativeQuery=true)
	public void reduceInventory( int qty) {
		 
	}
}
