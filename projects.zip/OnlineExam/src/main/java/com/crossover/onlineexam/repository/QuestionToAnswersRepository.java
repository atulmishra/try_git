package com.crossover.onlineexam.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.crossover.onlineexam.domain.Answers;
import com.crossover.onlineexam.domain.QuestionToAnswers;
import com.crossover.onlineexam.domain.Questions;

public interface QuestionToAnswersRepository extends JpaRepository<QuestionToAnswers, Integer> {

	List<QuestionToAnswers> findByQuestion(Questions question);
}
