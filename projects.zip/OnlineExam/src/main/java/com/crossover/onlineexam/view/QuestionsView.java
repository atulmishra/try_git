package com.crossover.onlineexam.view;

import java.util.List;

import com.crossover.onlineexam.domain.Answers;
import com.crossover.onlineexam.domain.Questions;

public class QuestionsView {
	
	Questions question;
	List<Answers> answers;
	public Questions getQuestion() {
		return question;
	}
	public void setQuestion(Questions question) {
		this.question = question;
	}
	public List<Answers> getAnswers() {
		return answers;
	}
	public void setAnswers(List<Answers> answers) {
		this.answers = answers;
	}
	public QuestionsView() {
		super();
		// TODO Auto-generated constructor stub
	}
	public QuestionsView(Questions question, List<Answers> answers) {
		super();
		this.question = question;
		this.answers = answers;
	}
	

}
