package com.crossover.onlineexam.repository;

public interface UserExamResponsesRepositoryCustom {
	public void reduceInventory(int qty);

}
