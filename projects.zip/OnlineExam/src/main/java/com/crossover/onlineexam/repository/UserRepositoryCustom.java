package com.crossover.onlineexam.repository;


public interface UserRepositoryCustom  {

	void increaseCurrentCredit(float val);
}
