package com.crossover.onlineexam.services;

import java.util.Date;

public class Timer implements Runnable{

	TimeLeft timeLeft;
	
	public TimeLeft getTimeLeft() {
		return timeLeft;
	}

	public void setTimeLeft(TimeLeft timeLeft) {
		this.timeLeft = timeLeft;
	}
	

	public Timer(TimeLeft timeLeft) {
		super();
		this.timeLeft = timeLeft;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
