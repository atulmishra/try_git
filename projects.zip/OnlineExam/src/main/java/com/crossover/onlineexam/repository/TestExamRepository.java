package com.crossover.onlineexam.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.crossover.onlineexam.domain.TestExam;

public interface TestExamRepository extends JpaRepository<TestExam, Integer> {

}
