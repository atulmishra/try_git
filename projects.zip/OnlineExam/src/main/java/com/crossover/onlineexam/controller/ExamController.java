package com.crossover.onlineexam.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.crossover.onlineexam.domain.UserExam;
import com.crossover.onlineexam.exceptions.EntityNotFound;
import com.crossover.onlineexam.services.ExamService;
import com.crossover.onlineexam.view.ExamView;
import com.crossover.onlineexam.view.UserExamView;
import com.crossover.onlineexam.view.UserResponseView;

@Controller
@RequestMapping("/exam/")
public class ExamController {
	
	private static final Logger logger = LoggerFactory.getLogger(ExamController.class);

	@Autowired
	private ExamService examService;
	
	
	@RequestMapping(value="getExamDetails/{code}",method = RequestMethod.GET)
	public @ResponseBody ExamView getExamDetails(@PathVariable("code") int examCode) {
		logger.debug("Received request to get details of exam no  : "+examCode);				

		return examService.getExamDescription(examCode);
	}
	
	@RequestMapping(value="/isTimeUp",method = RequestMethod.GET)
	public @ResponseBody boolean isTimeUp(@RequestParam("examId")  int examId) {
		logger.debug("Received request to get time left of exam no  : "+examId);				

		return examService.isTimeUp(examId);
	}


	@RequestMapping(value="getFullExamDetails/{code}",method = RequestMethod.GET)
	public @ResponseBody ExamView getFullExamDetails(@PathVariable("code") int examCode) {
		logger.debug("Received request to get full details of exam no  : "+examCode);				

		return examService.getFullExamDetails(examCode);
	}
	


	
	@RequestMapping(value="submitResponses",method = RequestMethod.POST)
	public @ResponseBody boolean submitResponses(@RequestBody List<UserResponseView> responses) throws EntityNotFound{
		logger.debug("Received request to submit user response for  : "+responses);				

		return examService.submitResponses(responses);
	}
	
	@RequestMapping(value="submitResults",method = RequestMethod.POST)
	public @ResponseBody UserExam submitResponse(@RequestBody UserExamView results) throws EntityNotFound{
		logger.debug("Received request to submit user results for  : "+results);				

		return examService.submitResult(results);
	}
	
	
	
	

}
