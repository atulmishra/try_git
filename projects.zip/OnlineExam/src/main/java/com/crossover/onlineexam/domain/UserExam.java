package com.crossover.onlineexam.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class UserExam {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	private long id;

	@Column
	private int marks;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getMarks() {
		return marks;
	}

	public void setMarks(int marks) {
		this.marks = marks;
	}

	@ManyToOne(optional = false)
	@JoinColumn(name = "username", unique = false, nullable = false, updatable = false)
	private User user;

	@OneToOne(optional = false)
	@JoinColumn(name = "exam_id", unique = true, nullable = false, updatable = false)
	private TestExam exam;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	
	public TestExam getExam() {
		return exam;
	}

	public void setExam(TestExam exam) {
		this.exam = exam;
	}

}
