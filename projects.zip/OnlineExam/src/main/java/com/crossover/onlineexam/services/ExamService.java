package com.crossover.onlineexam.services;

import java.util.List;

import com.crossover.onlineexam.domain.Answers;
import com.crossover.onlineexam.domain.TestExam;
import com.crossover.onlineexam.domain.UserExam;
import com.crossover.onlineexam.view.ExamView;
import com.crossover.onlineexam.view.UserExamView;
import com.crossover.onlineexam.view.UserResponseView;

public interface ExamService {
	public UserExam submitResult(UserExamView results)  ;
	public boolean submitResponses(List<UserResponseView> response)  ;
	public TestExam getExamDetails(int examCode);
	public List<Answers> getAnswersListFromQuestion(int questId);
	ExamView getExamDescription(int examCode);
	ExamView getFullExamDetails(int examCode);
	public boolean isTimeUp(int examId);


}
