package com.crossover.onlineexam.services;

import com.crossover.onlineexam.domain.User;


public interface UserService {
	public User login(String user,String password);

}
