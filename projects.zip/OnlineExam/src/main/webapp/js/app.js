					var module = angular.module("myapp", ['ngRoute','angularCharts']);

						module.directive('modal', function () {
									return {
									  template: '<div class="modal fade">' + 
										  '<div class="modal-dialog">' + 
											'<div class="modal-content">' + 
											  '<div class="modal-header">' + 
												'<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>' + 
												'<h4 class="modal-title">{{ title }}</h4>' + 
											  '</div>' + 
											  '<div class="modal-body" ng-transclude></div>' + 
											'</div>' + 
										  '</div>' + 
										'</div>',
									  restrict: 'E',
									  transclude: true,
									  replace:true,
									  scope:true,
									  link: function postLink(scope, element, attrs) {
										scope.title = attrs.title;

										scope.$watch(attrs.visible, function(value){
										  if(value == true)
											$(element).modal('show');
										  else
											$(element).modal('hide');
										});

										$(element).on('shown.bs.modal', function(){
										  scope.$apply(function(){
											scope.$parent[attrs.visible] = true;
										  });
										});

										$(element).on('hidden.bs.modal', function(){
										  scope.$apply(function(){
											scope.$parent[attrs.visible] = false;
										  });
										});
									  }
									};
								  });

							module.directive('topFiveOrders',function () {
						  	return {
						  		restrict: "EA",
						  		scope: {
						  			data: "="
						  		},
						  		templateUrl: "./views/topFiveOrders.html"
						  	}
						  });

							module.directive('topFiveSalesmen',function () {
						  	return {
						  		restrict: "EA",
						  		scope: {
						  			data: "="
						  		},
						  		templateUrl: "./views/topFiveSalesmen.html"
						  	}
						  });

									

							 module.config(['$routeProvider',
									function($routeProvider) {
										$routeProvider.
											when('/login', {
												templateUrl: './views/login.html',
												controller: 'LoginController'
											}).
									when('/home', {
												templateUrl: './views/home.html',
												controller: 'HomeController'
											}).
											when('/end', {
												templateUrl: './views/end-exam.html',
												controller: 'EndExamController'
											}).                
											otherwise({
												redirectTo: '/login'
											});
									}]);
							
							
					
					     module.controller("LoginController",["$rootScope", "$scope", "$http", "$location", function($rootScope, $scope, $http, $location) {
					       $scope.loginForm = {
								username:"",
								password:""
							};       

					        $scope.showBadCredentialsMessage = false;
					        $scope.openBadCreds=function(){
					        $scope.showBadCredentialsMessage = true;
					        };

					        $scope.logout=function(){
					        	$rootScope.sessionId = null;
								  $rootScope.username = null;
								  $location.path( "/login" );

					        }
					
					     $scope.loginForm.submitTheForm = function(item, event) {         

					       var responsePromise = $http.get("/OnlineExam/spring/login?username="+$scope.loginForm.username+"&password="+$scope.loginForm.password);
					       responsePromise.success(function(dataFromServer, status, headers, config) {          
							  if(dataFromServer.sessionId!=null){
								  $rootScope.sessionId = dataFromServer.sessionId;
								  $rootScope.username = $scope.loginForm.username;
								  $location.path( "/home" );
							}
					        else{
					             $scope.openBadCreds();
					        }
					       });
					        responsePromise.error(function(data, status, headers, config) {
					          alert("Server Error");
					          
					       });
					     }

					  }]);

module.controller("HomeController", ["$rootScope","$scope","$http","$location","$interval",function($rootScope, $scope, $http, $location,$interval) {

			$scope.checkIfLoggedIn= function(){
				if($rootScope.username===undefined||$rootScope.username==null){
					$location.path('/login');
				}
			};
			var callAtInterval = function(){
				var responsePromise = $http.get("/OnlineExam/spring/exam/isTimeUp?examId="+$scope.examDetails.examId);
					       responsePromise.success(function(dataFromServer, status, headers, config) {          
							 console.log(dataFromServer);
							 if(dataFromServer=="false"){
							 	$scope.sendResponsesWhenTimeUp();
							 	$scope.openTimeUpModal();
							 	$scope.stopInterval();
							 }
					       });
			};

			

			$scope.checkIfLoggedIn();
			$scope.getExamDetails = function(code) {
				$scope.examDetails={};
				$scope.currentQuestion;
				$scope.userResponses=[];
				$scope.user={response:""};
				$scope.checkedAnswers=[];

				$scope.toggleCheck = function (answer) {
       			 if ($scope.checkedAnswers.indexOf(answer) === -1) {
         		   $scope.checkedAnswers.push(answer);
        			} else {
       		    	 $scope.checkedAnswers.splice($scope.checkedAnswers.indexOf(answer), 1);
       			 	}
  				  };

				$http.get("/OnlineExam/spring/exam/getFullExamDetails/"+ code).then(function(response) {
					$scope.examDetails = angular.copy(response.data);

					$scope.currentQuestion=$scope.examDetails.questions[0];
					console.log($scope.examDetails);

					return true;

				}, function(result) {

					console.log("The request failed: " + result);
					return false;
				});

			};

						$scope.getExamDetails(1);
						var stop= $interval(callAtInterval, 2000);
						$scope.stopInterval = function() {
          					if (angular.isDefined(stop)) {
           					 $interval.cancel(stop);
          			 		 stop = undefined;
         				 }
       				 };
						var responseFromCheckedAnswers = function(){
							var response='';
							var length=$scope.checkedAnswers.length;
							for(var i=0;i<length;i++){
								response+=''+$scope.checkedAnswers[i].ansId;
								if(i!=length-1){response+=',';}

							}
							return response;
						};

							var getReponseByQuestionId =function (id) {
    							return _.find($scope.userResponses, function(response) {
   							     return response.questId == id;
 								   });
							};

						var checkUserResponseExists = function(response){

						var response = getReponseByQuestionId(response.questId);
						if(response){
							return $scope.userResponses.indexOf(response);
						} 
						return false;

						};
						$scope.submitResponse= function(userResponses){
							$http.post("/OnlineExam/spring/exam/submitResponses/",userResponses).then(
								function(response){
									console.log("The request submitted successfully: " );
									console.log(response);


								},function(result){
									console.log("The request failed: " + result);


								}

								);

						};

						var marksForMultipleChoice = function(question,answer){

							if(answer){
								var ansList = answer.split(",");
								var ansLength=question.answers.length;
								var totalCorrect=0;
								var markedCorrect=0;
								_.each(question.answers,function(ans){
									if(ans.correctChoice)totalCorrect++;
								});
							for(var i =0;i<ansLength;i++){
								
								var ans=question.answers[i];
								if(ansList.indexOf(''+ans.ansId)!=-1){
									if(ans.correctChoice){
										markedCorrect++;
									}
									
								} 
							}
							if(totalCorrect==markedCorrect)return 1;

							}
							return 0;
						}

						var getTotalMarks=function(userResponses){
							var totalMarks=0;
							_.each(userResponses,function(response){
								
								var question = _.find($scope.examDetails.questions, function(question) {
   							     return question.question.questId == response.questId;
 								   });
								if(question.question.multipleAnswer){
									totalMarks+=marksForMultipleChoice(question,response.userResponse)
								}else{
									var ans=_.findWhere(question.answers,{ansId:response.userResponse})
									if(ans){
									if(ans.correctChoice){
										totalMarks++;
									}
								}
								}

							});
							return totalMarks;
						};

						var setPreviouslySelectedCheckBoxes = function(userResponse){
						if (userResponse){
							var res = userResponse.split(",");
							var ansLength=$scope.currentQuestion.answers.length;
							for(var i =0;i<ansLength;i++){
								if(res.indexOf(''+$scope.currentQuestion.answers[i].ansId)!=-1){
									$scope.checkedAnswers.push($scope.currentQuestion.answers[i]);
								} 
							}
						}
						


					};
					$scope.setPreviouslySelectedAnswer=function(){
							$scope.checkedAnswers=[];
							var index=$scope.userResponses.indexOf($scope.currentQuestion);
							var response = _.findWhere($scope.userResponses, {questId: $scope.currentQuestion.question.questId}); 
								if(response){
								if($scope.currentQuestion.question.multipleAnswer===true){
									setPreviouslySelectedCheckBoxes(response.userResponse);
								}
								else{
								$scope.user.response= response.userResponse;
								}
							}
						};

						$scope.submitUserResults= function(userResponses){
							var totalMarks=getTotalMarks(userResponses);
							var payLoad={marks:totalMarks,username:$rootScope.username,examId:$scope.examDetails.examId};
							$http.post("/OnlineExam/spring/exam/submitResults/",payLoad).then(
								function(response){
									console.log("The request submitted successfully: " );
									console.log(response);


								},function(result){
									console.log("The request failed: " + result);


								}

								);

						};
						$scope.showQuestionNotAnswered = false;
						$scope.openAllQuestionsNotAnswered = function(){
							$scope.showQuestionNotAnswered=true;
						};
						$scope.closeAllQuestionsNotAnswered = function(){
							$scope.showQuestionNotAnswered=false;
						};


						$scope.showTimeup = false;
						$scope.openTimeUpModal = function(){
							$scope.showTimeup=true;
						};
						$scope.closeTimeUpModal = function(){
							$scope.showTimeup=false;
							$location.path('end');
						};

						var checkIfAllQuestionsAnswered = function(userResponses){
							return _.where(userResponses,{userResponse:""});
						};

						$scope.sendResponses =function(){
							$scope.submitResponse($scope.userResponses);
							$scope.submitUserResults($scope.userResponses);
							$scope.closeAllQuestionsNotAnswered();
							$location.path('/end');
							
						}

						$scope.sendResponsesWhenTimeUp =function(){
							$scope.submitResponse($scope.userResponses);
							$scope.submitUserResults($scope.userResponses);
							//$scope.closeTimeUpModal();
							//$location.path('/end');
							
						}

						$scope.goToNextQuestion = function (){
							
							
								console.log($scope.user.response);
								var userResponse;
							if($scope.currentQuestion.question.multipleAnswer===false){	
								 userResponse= {userName:$rootScope.username,examId:$scope.examDetails.examId, questId:$scope.currentQuestion.question.questId, userResponse:$scope.user.response};
							}
							else{
							userResponse= {userName:$rootScope.username,examId:$scope.examDetails.examId, questId:$scope.currentQuestion.question.questId, userResponse:responseFromCheckedAnswers()};

							}
							//$scope.checkedAnswers=[];
							//$scope.submitResponse(userResponse);
							

							if($scope.userResponses!=undefined){
								var answerExists=checkUserResponseExists(userResponse);
								if(  answerExists===false)	{
									$scope.userResponses.push(userResponse);
								}else{
									
									$scope.userResponses[answerExists].userResponse=userResponse.userResponse;
								}
							}
								var index=$scope.examDetails.questions.indexOf($scope.currentQuestion);
							if(index+1<$scope.examDetails.questions.length){

								$scope.currentQuestion=$scope.examDetails.questions[index+1];
								$scope.checkedAnswers=[];
								$scope.setPreviouslySelectedAnswer();
							}
							else{
									if($scope.userResponses.length!=$scope.examDetails.questions.length || checkIfAllQuestionsAnswered($scope.userResponses).length>0){
									$scope.openAllQuestionsNotAnswered();
									}
									else{
									$scope.sendResponses($scope.userResponses);
									}
								}

							
							};

					
						

						
						

		} ]);



						 module.controller("EndExamController",["$rootScope", "$scope", function($rootScope, $scope) { 		
							 $rootScope.sessionId = null;
							  $rootScope.username = null;

								  } ]);
