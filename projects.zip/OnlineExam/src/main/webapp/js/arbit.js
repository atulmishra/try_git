					var module = angular.module("myapp", ['ngRoute','angularCharts']);

						module.directive('modal', function () {
									return {
									  template: '<div class="modal fade">' + 
										  '<div class="modal-dialog">' + 
											'<div class="modal-content">' + 
											  '<div class="modal-header">' + 
												'<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>' + 
												'<h4 class="modal-title">{{ title }}</h4>' + 
											  '</div>' + 
											  '<div class="modal-body" ng-transclude></div>' + 
											'</div>' + 
										  '</div>' + 
										'</div>',
									  restrict: 'E',
									  transclude: true,
									  replace:true,
									  scope:true,
									  link: function postLink(scope, element, attrs) {
										scope.title = attrs.title;

										scope.$watch(attrs.visible, function(value){
										  if(value == true)
											$(element).modal('show');
										  else
											$(element).modal('hide');
										});

										$(element).on('shown.bs.modal', function(){
										  scope.$apply(function(){
											scope.$parent[attrs.visible] = true;
										  });
										});

										$(element).on('hidden.bs.modal', function(){
										  scope.$apply(function(){
											scope.$parent[attrs.visible] = false;
										  });
										});
									  }
									};
								  });

							module.directive('topFiveOrders',function () {
						  	return {
						  		restrict: "EA",
						  		scope: {
						  			data: "="
						  		},
						  		templateUrl: "./views/topFiveOrders.html"
						  	}
						  });

							module.directive('topFiveSalesmen',function () {
						  	return {
						  		restrict: "EA",
						  		scope: {
						  			data: "="
						  		},
						  		templateUrl: "./views/topFiveSalesmen.html"
						  	}
						  });

									

							 module.config(['$routeProvider',
									function($routeProvider) {
										$routeProvider.
											when('/login', {
												templateUrl: './views/login.html',
												controller: 'LoginController'
											}).
									when('/home', {
												templateUrl: './views/home.html',
												controller: 'HomeController'
											}).                
											otherwise({
												redirectTo: '/login'
											});
									}]);
							
							
					
					     module.controller("LoginController",["$rootScope", "$scope", "$http", "$location","LoginService", function($rootScope, $scope, $http, $location,LoginService) {
					       $scope.loginForm = {
								username:"",
								password:""
							};       

					        $scope.showBadCredentialsMessage = false;
					        $scope.openBadCreds=function(){
					        $scope.showBadCredentialsMessage = true;
					        };


					$scope.loginForm.submitTheForm1 = function(){
						if($scope.loginForm.username==""){
							$scope.loginForm.username=$scope.loginForm.username.$viewValue;
						}
					if(LoginService.authenticate1($scope.loginForm.username,$scope.loginForm.password)){
					$location.path( "/home" );
					}
					else{
					             $scope.openBadCreds();
					        }

					        if(LoginService.getExamDetails(1)){
					        	console.log("gotExam");
					        }
					        if(LoginService.getQuestionToAnswersDetails(1)){
					        	console.log("getQuestionToAnswersDetails");
					        }

					};

					     $scope.loginForm.submitTheForm = function(item, event) {         

					       var responsePromise = $http.get("http://localhost:8080/OnlineExam/spring//login?username="+$scope.loginForm.username+"&password="+$scope.loginForm.password);
					       responsePromise.success(function(dataFromServer, status, headers, config) {          
							  if(dataFromServer.loginSucceeded){
								  $rootScope.sessionId = dataFromServer.sessionId;
								  $rootScope.username = $scope.loginForm.username;
								  $location.path( "/home" );
							}
					        else{
					             $scope.openBadCreds();
					        }
					       });
					        responsePromise.error(function(data, status, headers, config) {
					          alert("Server Error");
					          
					       });
					     }

					  }]);

				module.factory("LoginService",['$rootScope','$http',function($rootScope, $http){
					var fac={};
					fac.authenticatePromise=function(username,password){
						return $http.get("http://localhost:8080/OnlineExam/spring/login?username="+username+"&password="+password);

					};

						fac.authenticate1=function(username,password){

						$http.get("http://localhost:8080/OnlineExam/spring/login?username="+username+"&password="+password)
				  .then(function(response) {
				  							  $rootScope.sessionId = response.data.sessionId;
									  $rootScope.username = username;
				    console.log("Your name is: " + $rootScope.sessionId);
				    return true;

				  }, function(result) {

				    console.log("The request failed: " + result);
				    return false;
				  });


					};
					fac.getExamDetails=function(code){

						$http.get("http://localhost:8080/OnlineExam/spring/exam/getFullExamDetails/"+code)
				  .then(function(response) {
				  							  $rootScope.sessionId = response.data.sessionId;
									  $rootScope.username = username;
				    console.log("Your response is: " +response);
				    return true;

				  }, function(result) {

				    console.log("The request failed: " + result);
				    return false;
				  });


					};

					fac.getQuestionToAnswersDetails=function(code){

						$http.get("http://localhost:8080/OnlineExam/spring/exam/getAnswers/"+code)
				  .then(function(response) {
				  							  $rootScope.sessionId = response.data.sessionId;
									  $rootScope.username = username;
				    console.log("Your response is: " +response);
				    return true;

				  }, function(result) {

				    console.log("The request failed: " + result);
				    return false;
				  });


					};



					fac.authenticate2=function(username,password){

					$http.post("http://localhost:8080/OnlineExam/spring/login",{username:'username',password:'password'})
			  .then(function(response) {
			  							  $rootScope.sessionId = response.data.sessionId;
								  $rootScope.username = username;
			    console.log("Your name is: " + $rootScope.sessionId);
			    return true;

			  }, function(result) {

			    console.log("The request failed: " + result);
			    return false;
			  });


					};



					fac.authenticate=function(username,password){

					var responsePromise = $http.get("http://localhost:8080/OnlineExam/spring/login?username="+username+"&password="+password);


					       responsePromise.success(function(dataFromServer, status, headers, config) {          
							  if(dataFromServer.loginSucceeded){
								  $rootScope.sessionId = dataFromServer.sessionId;
								  $rootScope.username = username;
								  return true;
							}
					        else{
					             return false;
					        }
					       });
					        responsePromise.error(function(data, status, headers, config) {
					          return false;
					          
					       });

					}
					return fac;

					}]);	


						  module.controller("HomeController", ["$rootScope", "$scope", "$http", "$location",function($rootScope, $scope, $http, $location) {
							$scope.displayChart = false;	
							$scope.displayPieChart = false;	
							$scope.displayTopFiveOrders = false;	
							$scope.displayTopFiveSalesmen = false;
							

							$scope.closeChart = function(prop){
								$scope[prop] = false;	
							};
							

							$scope.showSalesChart = function() {		   
								
								var responsePromise = $http.get("http://localhost:8080/lastyeardata?sessionid="+$rootScope.sessionId);
								responsePromise.success(function(dataFromServer, status, headers, config) {          
								  if(dataFromServer.resultDescription=="SUCCESS"){
									  $scope.config = {
										title: 'Sales total per Month',
										tooltips: true,
										labels: false,
										mouseover: function() {},
										mouseout: function() {},
										click: function() {},
										legend: {
										  display: true,
										  //could be 'left, right'
										  position: 'right'
										}
									 };
									 
									   $scope.data = {
										series: ['Sales'],
										data: []					
										};
										
										var length = dataFromServer.data.length;
										for(var i=0;i< length;i++){
										  var salesman = dataFromServer.data[i];
										  var chartElement={
										    x:salesman[0],
											y:[parseInt(salesman[1])]
										  }
										  $scope.data.data.push(chartElement);
										}
										
									$scope.displayChart = true;	
									$scope.displayPieChart = false;	
									$scope.displayTopFiveOrders = false;	
									$scope.displayTopFiveSalesmen = false;										
								    }// end of If
							    });
								
								responsePromise.error(function(data, status, headers, config) {
								  alert("You are not logged in");
								});	
								
								 
							};	


							
							$scope.showPieChart = function() {
							   
							
								var responsePromise = $http.get("http://localhost:8080/salesmandata?sessionid="+$rootScope.sessionId);
								responsePromise.success(function(dataFromServer, status, headers, config) {          
								  if(dataFromServer.resultDescription=="SUCCESS"){
									  $scope.pieConfig = {
										title: 'Sales total per Salesman',
										tooltips: true,
										labels: false,
										mouseover: function() {},
										mouseout: function() {},
										click: function() {},
										legend: {
										  display: true,
										  //could be 'left, right'
										  position: 'right'
										},
										 innerRadius: 0,
									 };
									 
									   $scope.pieData = {
										series: ['Sales'],
										data: []					
										};
										
										var length = dataFromServer.data.length;
										for(var i=0;i< length;i++){
										  var salesman = dataFromServer.data[i];
										  var chartElement={
										    x:salesman[0],
											y:[parseInt(salesman[1])]
										  }
										  $scope.pieData.data.push(chartElement);
										}
										
									$scope.displayPieChart = true;	
									$scope.displayChart = false;			
									$scope.displayTopFiveOrders = false;	
									$scope.displayTopFiveSalesmen = false;
								    }// end of If
							    });
								
								responsePromise.error(function(data, status, headers, config) {
								  alert("You are not logged in");
								});	
									
								 
							};		

						

							$scope.showTopFiveOrders = function () {
								
								
									var responsePromise = $http.get("http://localhost:8080/topsalesorders?sessionid="+$rootScope.sessionId);
									responsePromise.success(function(dataFromServer, status, headers, config) {          
									  	if(dataFromServer.resultDescription=="SUCCESS"){
										 	$scope.topFiveOrdersData = dataFromServer.data;
											
											$scope.displayTopFiveOrders = true;	
											$scope.displayChart = false;	
							                $scope.displayPieChart = false;				
							                $scope.displayTopFiveSalesmen = false;
									    }// end of If
							    	});
								
									responsePromise.error(function(data, status, headers, config) {
									  alert("You are not logged in");
									});	
										
							};	

							

							$scope.showTopFiveSalesmen = function () {
								
								
									var responsePromise = $http.get("http://localhost:8080/topsalesmen?sessionid="+$rootScope.sessionId);
									responsePromise.success(function(dataFromServer, status, headers, config) {          
									  	if(dataFromServer.resultDescription=="SUCCESS"){
										 	$scope.topFiveSalesmenData = dataFromServer.data;
											
											$scope.displayTopFiveSalesmen = true;	
											$scope.displayChart = false;	
							                $scope.displayPieChart = false;	
							                $scope.displayTopFiveOrders = false;	
							
									    }// end of If
							    	});
								
									responsePromise.error(function(data, status, headers, config) {
									  alert("You are not logged in");
									});	
								
							};			

							
							
							$scope.logout = function(){
								var responsePromise = $http.get("http://localhost:8080/logout?sessionid="+$rootScope.sessionId);
								
								responsePromise.success(function(dataFromServer, status, headers, config) {          
								  if(dataFromServer=="SUCCESS"){
									  $rootScope.sessionId = null;
									  $rootScope.username = null;
									  $location.path( "/login" );
								    }
							    });
							   
								responsePromise.error(function(data, status, headers, config) {
								  alert("There is some problem logging out");
								});					
							};  	 
								  }]);//end of home controller
						  
						

						  
						  module.controller("FooterController",["$rootScope", "$scope", function($rootScope, $scope) { 		
						    $scope.supportForm ={
								subject:"",
								details:""
							};
							$scope.showPrivacyPolicy = false;
							$scope.showTermOfUse = false;
							$scope.showSupport = false;	
							$scope.showSuccessMessage = false;
							$scope.openPrivacyPolicy = function(){
								$scope.showPrivacyPolicy = true;
							};
							$scope.openTermsOfUse = function(){
								$scope.showTermOfUse = true;
							};
							$scope.openSupportForm = function(){
								$scope.showSupport = true;
							};
							$scope.closeSupportForm = function(){
								$scope.showSupport = false;
							};
							$scope.sendSupportForm = function(){
								$scope.showSuccessMessage = true;
								$scope.supportForm.subject = null;
								$scope.supportForm.details = null;
								$scope.closeSupportForm();
							};
						 

								  } ]);
