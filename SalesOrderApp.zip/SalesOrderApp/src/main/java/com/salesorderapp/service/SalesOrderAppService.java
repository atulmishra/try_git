package com.salesorderapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.salesorderapp.dao.impl.ZipCodeDaoImpl;
import com.salesorderapp.model.InputTypeEnum;
import com.salesorderapp.model.ZipCode;

public class SalesOrderAppService {
@Autowired
ZipCodeDaoImpl zipCodeDaoImpl;
	
	public ZipCode getZipcodebyZip(int zip){
		return zipCodeDaoImpl.findByZip(zip);
	}
	public String getType(String input){
		return zipCodeDaoImpl.findType(input);
	}
	
	public List<ZipCode> getCitiesByState(String state){
		return zipCodeDaoImpl.findCitiesByState(state);
	}
	
	public List<ZipCode> getStatesByCity(String city){
		return zipCodeDaoImpl.findStatesByCity(city);
	}
	
	public List<ZipCode> getZipCodesByUniqueCity(String city){
		return zipCodeDaoImpl.findZipCodesByUniqueCity(city);
	}
	
	public List<ZipCode> getZipCodesListByStateAndCity(String state,String city){
		return zipCodeDaoImpl.findZipCodesByStateAndCity(state, city);
	}
	
	
	
}
