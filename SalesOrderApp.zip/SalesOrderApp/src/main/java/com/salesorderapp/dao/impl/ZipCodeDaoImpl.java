package com.salesorderapp.dao.impl;

import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.salesorderapp.dao.ProductDao;
import com.salesorderapp.model.InputTypeEnum;
import com.salesorderapp.model.ZipCode;
import com.salesorderapp.model.ZipCodeMapper;


public class ZipCodeDaoImpl  extends JdbcDaoSupport implements ProductDao{

	public static boolean isNumeric(String str)
	{
	  return str.matches("-?\\d+(\\.\\d+)?");  //match a number with optional '-' and decimal.
	}
	
	public ZipCode findByZip(int zip) {
		
		String sql = "SELECT * FROM zipcodes WHERE zip = ?";
		 
		ZipCode zipcode = (ZipCode)getJdbcTemplate().queryForObject(
				sql, new Object[] { zip }, new ZipCodeMapper());
	 
		return zipcode;
	}
	

	
	

	public List<ZipCode> findZipCodesByStateAndCity(String state,String city){
		String sql = "SELECT * FROM zipcodes where state =? and city=?";
		 
		List<ZipCode> zipcodesList  = getJdbcTemplate().query(sql,new Object[] { state , city},
				new ZipCodeMapper());
	 
		return zipcodesList;
	}
	
	public List<ZipCode> findCitiesByState(String state){
		String sql = "SELECT * FROM cityToStateMapping where state =?";
		 
		List<ZipCode> citiesList  = getJdbcTemplate().query(sql,new Object[] { state },
				new ZipCodeMapper());
	 
		return citiesList;
	}
	
	public List<ZipCode> findStatesByCity(String city){
		String sql = "SELECT * FROM cityToStateMapping where city =?";
		 
		List<ZipCode> statesList  = getJdbcTemplate().query(sql,new Object[] { city },
				new ZipCodeMapper());
	 
		return statesList;
	}
	
	public List<ZipCode> findZipCodesByUniqueCity(String city){
		String sql = "SELECT * FROM zipcodes where city =?";
		 
		List<ZipCode> zipCodesList  = getJdbcTemplate().query(sql,new Object[] { city },
				new ZipCodeMapper());
	 
		return zipCodesList;
	}

	public String findType(String input) {
		String type = InputTypeEnum.INVALID.getValue();
		String sql=null;
		int count=0;
		//first check for zip
		if(isNumeric(input)){
			//type=InputTypeEnum.NUNIQUECITY.getValue();
				int i=Integer.parseInt(input);	
			 sql = "SELECT count(*) FROM zipcodes WHERE zip = ?";
		 
			 count = getJdbcTemplate().queryForObject(
		                        sql, new Object[] { i }, Integer.class);
			if (count > 0) {
				type=InputTypeEnum.ZIP.getValue();
				return type;
			}
		}
		//check for state
		sql="SELECT count(*) FROM zipcodes WHERE state = ?";
		count=0;
		 count = getJdbcTemplate().queryForObject(
                 sql, new Object[] { input }, Integer.class);
		
		 if (count > 0) {
				type=InputTypeEnum.STATE.getValue();
				return type;
			}
		 
		 //check for not a unique city
		 sql="SELECT count(*) FROM cityToStateMapping WHERE city = ?";
			count=0;
			 count = getJdbcTemplate().queryForObject(
	                 sql, new Object[] { input }, Integer.class);
			
			 if (count > 1) {
					type=InputTypeEnum.NUNIQUECITY.getValue();
					return type;
				}
		 //check for unique city
			 sql="SELECT count(*) FROM cityToStateMapping WHERE city = ?";
				count=0;
				 count = getJdbcTemplate().queryForObject(
		                 sql, new Object[] { input }, Integer.class);
				
				 if (count == 1) {
						type=InputTypeEnum.UNIQUECITY.getValue();
						return type;
					} 
		
		return type;
	}

}
