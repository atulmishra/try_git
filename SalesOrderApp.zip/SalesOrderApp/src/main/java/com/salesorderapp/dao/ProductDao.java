package com.salesorderapp.dao;

import java.util.List;

import com.salesorderapp.model.ZipCode;

public interface ProductDao {
	
	public String findType(String input);
	
	public ZipCode findByZip(int zip);
	
	public List<ZipCode> findCitiesByState(String state);
	
	public List<ZipCode> findStatesByCity(String city);
	
	public List<ZipCode> findZipCodesByStateAndCity(String state,String city);
	
	public List<ZipCode> findZipCodesByUniqueCity(String city);

	

	
	
	

}
