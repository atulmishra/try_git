package com.salesorderapp.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.salesorderapp.model.InputTypeEnum;
import com.salesorderapp.model.ZipCode;
import com.salesorderapp.service.SalesOrderAppService;

@Controller
public class SalesOrderAppServlet {
	
	@Autowired
	SalesOrderAppService zipCodeLookupService;

	@RequestMapping(value="/lookup",method = RequestMethod.POST,
            headers = {"Content-type=application/json"})
	public @ResponseBody ZipCode lookup(@RequestBody ZipCode zipcode) {
		
		return zipCodeLookupService.getZipcodebyZip(zipcode.getZip());
	}
	
	@RequestMapping(value="/type",method = RequestMethod.GET)
	public @ResponseBody String lookupType(@RequestParam("address") String input) {
		
		return zipCodeLookupService.getType(input);
	}
	
	@RequestMapping(value="/state",method = RequestMethod.POST,
            headers = {"Content-type=application/json"})
	public @ResponseBody List<ZipCode> lookupByState(@RequestBody ZipCode zipcode,BindingResult results) {
		
		return zipCodeLookupService.getCitiesByState(zipcode.getState());
	}
	
	@RequestMapping(value="/city",method = RequestMethod.POST,
            headers = {"Content-type=application/json"})
	public @ResponseBody List<ZipCode> lookupByCity(@RequestBody ZipCode zipcode) {
		
		return zipCodeLookupService.getStatesByCity(zipcode.getCity());
	}
	
	@RequestMapping(value="/cityunique",method = RequestMethod.POST,
            headers = {"Content-type=application/json"})
	public @ResponseBody List<ZipCode> lookupByUniqueCity(@RequestBody ZipCode zipcode) {
		
		return zipCodeLookupService.getZipCodesByUniqueCity(zipcode.getCity());
	}
	
	
	@RequestMapping(value="/citystate",method = RequestMethod.POST,
            headers = {"Content-type=application/json"})
	public @ResponseBody List<ZipCode> lookupCityState(@RequestBody ZipCode zipcode) {
		
		return zipCodeLookupService.getZipCodesListByStateAndCity(zipcode.getState(),zipcode.getCity());
	}

}