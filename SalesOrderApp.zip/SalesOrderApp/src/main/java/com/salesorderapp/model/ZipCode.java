package com.salesorderapp.model;

public class ZipCode {

	private int zip;
	private String city;
	private String state;
	private float latitude;
	private float longitude;
	private float timezone;
	private float dst;
	public ZipCode(){
		
	}
	public ZipCode(int zip, String city, String state, float latitude,
			float longitude, float timezone, float dst) {
		super();
		this.zip = zip;
		this.city = city;
		this.state = state;
		this.latitude = latitude;
		this.longitude = longitude;
		this.timezone = timezone;
		this.dst = dst;
	}
	public int getZip() {
		return zip;
	}
	public void setZip(int zip) {
		this.zip = zip;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public float getLatitude() {
		return latitude;
	}
	public void setLatitude(float latitude) {
		this.latitude = latitude;
	}
	public float getLongitude() {
		return longitude;
	}
	public void setLongitude(float longitude) {
		this.longitude = longitude;
	}
	public float getTimezone() {
		return timezone;
	}
	public void setTimezone(float timezone) {
		this.timezone = timezone;
	}
	public float getDst() {
		return dst;
	}
	public void setDst(float dst) {
		this.dst = dst;
	}
	}
