package com.salesorderapp.model;

public enum InputTypeEnum {
	ZIP("zip"),STATE("state"),UNIQUECITY("uniqueCity"),NUNIQUECITY("notUniqueCity"),INVALID("invalid");
	public String getValue() {
		return value;
	}


	public void setValue(String value) {
		this.value = value;
	}


	private String value;
	

	private InputTypeEnum(String value){
		this.value=value;
	}
	

}
