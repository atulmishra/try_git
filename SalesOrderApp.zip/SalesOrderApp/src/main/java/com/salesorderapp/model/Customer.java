package com.salesorderapp.model;

public class Customer {
	
	private int id;
	private String code;
	private String name;
	private String phone1;
	private String phone2;
	private float credit_limit;
	private float current_credit;
	
	//getters and setters
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone1() {
		return phone1;
	}
	public void setPhone1(String phone1) {
		this.phone1 = phone1;
	}
	public String getPhone2() {
		return phone2;
	}
	public void setPhone2(String phone2) {
		this.phone2 = phone2;
	}
	public float getCredit_limit() {
		return credit_limit;
	}
	public void setCredit_limit(float credit_limit) {
		this.credit_limit = credit_limit;
	}
	public float getCurrent_credit() {
		return current_credit;
	}
	public void setCurrent_credit(float current_credit) {
		this.current_credit = current_credit;
	}
	
	

}
