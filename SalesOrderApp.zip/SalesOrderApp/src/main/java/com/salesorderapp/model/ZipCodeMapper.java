package com.salesorderapp.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;;

public class ZipCodeMapper  implements RowMapper{

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
	      ZipCode zipcode = new ZipCode();
	      zipcode.setZip((int)(rs.getFloat("zip")));
	      zipcode.setCity(rs.getString("city"));
	      zipcode.setState(rs.getString("state"));
	      zipcode.setLatitude(rs.getFloat("latitude"));
	      zipcode.setLongitude(rs.getFloat("longitude"));
	      zipcode.setTimezone(rs.getFloat("timezone"));
	      zipcode.setDst(rs.getFloat("dst"));
	      return zipcode;
	   }
}
