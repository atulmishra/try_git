package com.citi.otc.dashboard.services;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.citi.otc.dashboard.domain.JobsDescription;
import com.citi.otc.dashboard.repository.JobsDescriptionRepository;
@Service
@Scope("prototype")
public class JobServiceImpl implements JobService {
	
	@Resource
	JobsDescriptionRepository jobRepository ;

	@Override
	public JobsDescription getJobDetails(Long jobId) {
		return jobRepository.findOne(jobId);
	}

	@Override
	public List<JobsDescription> getAllJobs() {
		// TODO Auto-generated method stub
		return jobRepository.findAll();
	}

}
