package com.citi.otc.dashboard.view;

public class JobView {

}
