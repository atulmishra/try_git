package com.citi.otc.dashboard.services;

import java.util.List;

import com.citi.otc.dashboard.domain.JobsDescription;

public interface JobService {
	public JobsDescription getJobDetails(Long jobId);
	public List<JobsDescription> getAllJobs();
	
	
}
