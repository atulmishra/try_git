package com.citi.otc.dashboard.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.citi.otc.dashboard.domain.JobsDescription;
import com.citi.otc.dashboard.services.JobService;

@Controller
@RequestMapping("/job/")
public class JobController {
	
	private static final Logger logger = LoggerFactory.getLogger(JobController.class);

	@Autowired
	private JobService jobService;
	
	
	@RequestMapping(value="getJobDetails/{id}",method = RequestMethod.GET)
	public @ResponseBody JobsDescription getExamDetails(@PathVariable("id") Long id) {
		logger.debug("Received request to get details of job ID  : "+id);				

		return jobService.getJobDetails(id);
	}
	
	@RequestMapping(value="getAllJobs",method = RequestMethod.GET)
	public @ResponseBody List<JobsDescription> getJobDetails() {
		logger.debug("Received request to get details of all jobs ");				

		return jobService.getAllJobs();
	}
	
	
	
	
	
	

}
