					var module = angular.module("myapp", ['ngRoute','angularCharts','smart-table']);

					

									

							 module.config(['$routeProvider',
									function($routeProvider) {
										$routeProvider.
											
									when('/home', {
												templateUrl: './views1/home.html',
												controller: 'HomeController'
											}).
											            
											otherwise({
												redirectTo: '/home'
											});
									}]);
							
							
					
					    
module.controller("HomeController", ["$rootScope","$scope","$http","$location","$interval",function($rootScope, $scope, $http, $location,$interval) {

							$scope.jobs = {};


					       var responsePromise = $http.get("/otcdashboard/spring/job/getAllJobs");
					        responsePromise.success(function(dataFromServer, status, headers, config) {          
							  if(dataFromServer!=null){
								 $scope.jobs = dataFromServer;
							}
					        
					       });

						 responsePromise.error(function(data, status, headers, config) {
					          alert("Server Error");
					          
					       });

						 $scope.predicates = ['jobId','appId'];
						 $scope.selectedPredicate = $scope.predicates[0];


						

		} ]);



						
